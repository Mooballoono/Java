

public class pig2{
	public static void main(String[]args){
		myFrame frame = new myFrame();
		myFrame2 frame2 = new myFrame2();
	}
}